
package com.ericsson.teamname.integrationtest.test.data;

import java.util.List;
import java.util.Map;

import org.testng.annotations.DataProvider;

import com.ericsson.cifwk.taf.TestData;
import com.ericsson.cifwk.taf.data.Host;
import com.ericsson.teamname.integrationtest.data.RemoteFileHandlerDataProvider;
import com.ericsson.teamname.integrationtest.data.RestToolDataProvider;
import com.ericsson.teamname.integrationtest.data.SSHRemoteExecutorDataProvider;
/**
 *
 *	Test DataProvider for executing Test Cases for RemoteFileHandler
 */
public class SSHRemoteExecutorTestDataProvider implements TestData{

	static SSHRemoteExecutorDataProvider dataProvider = new SSHRemoteExecutorDataProvider();


	@DataProvider(name = "remoteHostData")
	public static Object[][] restCallArguments() {
		/*
		 * All data are fetched from Data Provider. 
		 * Data Provider is containing logic on how and from where to get the data
		 */
		List<String> callTypeList = RestToolDataProvider.getCallType();
		
		
		/*
		 * This method need to return Object[][] where first dimension is amount of calls of test method and data combinations
		 * and second dimension is amount of arguments required by test method
		 */
		Object[][] result = new Object[dataProvider.getScripts().size()][];
		int idx = 0;
		for (String item : callTypeList){
			Object[] testMethodArguments = new Object[3];
			testMethodArguments[0] = dataProvider.getHosts().get(idx);
			testMethodArguments[1] = dataProvider.getScripts().get(idx);
			testMethodArguments[2] = dataProvider.getExpected().get(idx);
			result[idx] = testMethodArguments;
			idx++;
		}
		return result;
	}
}