
package com.ericsson.teamname.integrationtest.operators;




import org.apache.log4j.Logger;


import com.ericsson.cifwk.taf.GenericOperator;
import com.ericsson.cifwk.taf.data.Host;
import com.ericsson.teamname.integrationtest.operators.api.*;
/**
 *
 *	Operator for executing Test Cases for RemoteFileHandler
 */
public class SSHRemoteExecutorOperator implements GenericOperator{

	SSHRemoteExecutorApiOperator apiOperator = new SSHRemoteExecutorApiOperator();
	String expectedResult = "";
	Logger log = Logger.getLogger(SSHRemoteExecutorOperator.class);
	
	public boolean execute(Host host, String script){
		expectedResult = apiOperator.execute(host, script);
		log.debug("STDOUT " +expectedResult);
		return true;
	}

	public boolean expect(String expect){
		if (expectedResult.contains(expect)){
			return true;
		}
		else{
			return false;
		}
	}

	
}