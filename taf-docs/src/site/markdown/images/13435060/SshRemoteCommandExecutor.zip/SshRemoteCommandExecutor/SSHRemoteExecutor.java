package com.ericsson.teamname.integrationtest.test.cases;

import org.testng.annotations.Test;

import com.ericsson.cifwk.taf.TestCase;
import com.ericsson.cifwk.taf.TorTestCaseHelper;
import com.ericsson.cifwk.taf.annotations.Context;
import com.ericsson.cifwk.taf.annotations.VUsers;
import com.ericsson.cifwk.taf.data.Host;
import com.ericsson.teamname.integrationtest.operators.SSHRemoteExecutorOperator;
import com.ericsson.teamname.integrationtest.test.data.SSHRemoteExecutorTestDataProvider;


/**
 * 
 *
 * @author egergle
 *
 */
public class SSHRemoteExecutor extends TorTestCaseHelper implements TestCase {
	SSHRemoteExecutorOperator ssHRemoteExecutorOperator = new SSHRemoteExecutorOperator();

	/**
	 *
	 *  @PRIORITY HIGH
	 */
	@Context(context = { Context.API })
	@VUsers(vusers = { 1 })
	@Test(groups = { "AcceptanceTest" }, dataProvider = "remoteHostData", dataProviderClass = SSHRemoteExecutorTestDataProvider.class)
	public void sendCLICommand(Host host, String script, String expect) {
		setTestCase("Test example", "some text here");

		setTestStep("Send a cli command and verify the expected output");
		assert ssHRemoteExecutorOperator.execute(host, script) == ssHRemoteExecutorOperator.expect(expect);
	}

	
}