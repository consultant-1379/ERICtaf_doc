package com.ericsson.teamname.integrationtest.operators.api;

import org.apache.log4j.Logger;

import com.ericsson.cifwk.taf.ApiOperator;
import com.ericsson.cifwk.taf.data.Host;
import com.ericsson.cifwk.taf.handlers.implementation.SshRemoteCommandExecutor;
import com.ericsson.teamname.integrationtest.getters.api.SSHRemoteExecutorApiGetter;

public class SSHRemoteExecutorApiOperator implements ApiOperator{

    private final Logger logger = Logger.getLogger(SSHRemoteExecutorApiOperator.class);
    SSHRemoteExecutorApiGetter sshRemoteExecutorApiGetter = new SSHRemoteExecutorApiGetter();
    

    public String execute(Host host, String script){
    	SshRemoteCommandExecutor sshRemoteCommandExecutor = new SshRemoteCommandExecutor(host);
    	return sshRemoteCommandExecutor.simplExec(sshRemoteExecutorApiGetter.getScript(script));
    }
	
}
