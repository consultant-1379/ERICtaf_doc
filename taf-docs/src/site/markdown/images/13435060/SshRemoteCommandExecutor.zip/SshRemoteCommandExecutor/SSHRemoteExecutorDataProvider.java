
package com.ericsson.teamname.integrationtest.data;
import java.util.ArrayList;
import java.util.List;

import com.ericsson.cifwk.taf.DataProvider;
import com.ericsson.cifwk.taf.data.DataHandler;
import com.ericsson.cifwk.taf.data.Host;

/**
 *
 *	DataProvider for executing Test Cases for RemoteFileHandler
 */
public class SSHRemoteExecutorDataProvider implements DataProvider{

	List<String> scripts;

	public List<String> getScripts(){
		scripts = new ArrayList<String>();
		scripts.add("CDRoot");	
		return scripts;
	}
	
	public List<String> getExpected(){
		List<String> expected = new ArrayList<String>();
		expected.add("boot");
		return expected;
	}

	/**
	 * Get the host object to use for these tests
	 * @return the vm9 host object
	 */
	public List<Host> getHosts(){
		List<Host> result = new ArrayList<Host>();
		result.add(DataHandler.getHostByName("sc2"));
		return result;
	}
}