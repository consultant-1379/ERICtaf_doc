package com.ericsson.teamname.integrationtest.getters.api;

import com.ericsson.cifwk.taf.ApiGetter;
import com.ericsson.cifwk.taf.data.DataHandler;
import com.ericsson.cifwk.taf.data.Host;
import com.ericsson.cifwk.taf.handlers.RemoteFileHandler;
/**
 *
 *	API Context Getter for executing Test Cases for RemoteFileHandler
 */
public class SSHRemoteExecutorApiGetter implements ApiGetter{

	public String getScript(String script){
		return DataHandler.getAttribute(script).toString();
	}
}